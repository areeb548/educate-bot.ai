const page = document.body.dataset.page;
const yearEl = document.querySelector('[data-year]');
if (yearEl) {
  yearEl.textContent = String(new Date().getFullYear());
}

const renderStatus = (node, type, message) => {
  node.textContent = message;
  node.className = type;
};

const handleAuth = async (endpoint, form) => {
  const statusEl = form.querySelector('.status') || (() => {
    const div = document.createElement('div');
    div.className = 'status';
    form.append(div);
    return div;
  })();

  renderStatus(statusEl, 'status', 'Submitting...');

  const formData = new FormData(form);
  const payload = Object.fromEntries(formData.entries());

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      credentials: 'include',
    });

    if (!res.ok) {
      const error = await res.json().catch(() => ({}));
      throw new Error(error?.message || 'Request failed');
    }

    renderStatus(statusEl, 'success', 'Success! Redirecting...');
    window.location.href = '/app.html';
  } catch (error) {
    renderStatus(statusEl, 'error', error.message);
  }
};

if (page === 'signup') {
  const form = document.getElementById('signup-form');
  form?.addEventListener('submit', (event) => {
    event.preventDefault();
    handleAuth('/api/auth/signup', form);
  });
}

if (page === 'login') {
  const form = document.getElementById('login-form');
  form?.addEventListener('submit', (event) => {
    event.preventDefault();
    handleAuth('/api/auth/login', form);
  });
}
