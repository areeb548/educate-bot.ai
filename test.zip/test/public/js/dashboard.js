const page = document.body.dataset.page;
const yearEl = document.querySelector('[data-year]');
if (yearEl) {
  yearEl.textContent = String(new Date().getFullYear());
}

const createStatus = (form) => {
  let node = form.querySelector('#form-status');
  if (!node) {
    node = document.createElement('div');
    node.id = 'form-status';
    form.append(node);
  }
  return node;
};

const renderStatus = (node, type, message) => {
  node.textContent = message;
  node.className = type;
};

const formatDate = (value) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleString();
};

if (page === 'dashboard') {
  const logoutBtn = document.getElementById('logout-btn');
  const form = document.getElementById('question-form');
  const previewContainer = document.getElementById('preview-container');
  const feedContent = document.getElementById('feed-content');

  const ensureAuth = async () => {
    const res = await fetch('/api/auth/me', { credentials: 'include' });
    if (!res.ok) {
      window.location.href = '/login.html';
      return null;
    }
    return res.json();
  };

  const renderEntry = (entry, prepend = false) => {
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <header>
        <span>${entry.subject || 'Unknown subject'}</span>
        <time>${formatDate(entry.createdAt)}</time>
      </header>
      <div>
        <strong>Question</strong>
        <p>${entry.question.replace(/</g, '&lt;')}</p>
      </div>
      <div>
        <strong>Answer</strong>
        <pre>${entry.answer.replace(/</g, '&lt;')}</pre>
      </div>
    `;

    if (entry.imagePath) {
      const img = document.createElement('img');
      img.src = entry.imagePath;
      img.alt = 'Uploaded reference';
      img.className = 'image-preview';
      card.append(img);
    }

    if (prepend && feedContent.firstChild) {
      feedContent.insertBefore(card, feedContent.firstChild);
    } else {
      feedContent.append(card);
    }
  };

  const loadEntries = async () => {
    feedContent.innerHTML = '';
    const res = await fetch('/api/questions', { credentials: 'include' });
    if (!res.ok) {
      const msg = document.createElement('div');
      msg.className = 'error';
      msg.textContent = 'Failed to load previous answers.';
      feedContent.append(msg);
      return;
    }
    const data = await res.json();
    if (!data.length) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Submit your first question to see AI answers here.';
      feedContent.append(empty);
      return;
    }
    data.forEach((item) => renderEntry(item));
  };

  const handleImagePreview = (file) => {
    previewContainer.innerHTML = '';
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = document.createElement('img');
      img.src = event.target.result;
      img.alt = 'Preview';
      img.className = 'image-preview';
      previewContainer.append(img);
    };
    reader.readAsDataURL(file);
  };

  form?.image?.addEventListener('change', (event) => {
    const file = event.target.files?.[0];
    handleImagePreview(file);
  });

  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const statusNode = createStatus(form);
    renderStatus(statusNode, 'status', 'Sending to AI...');

    const formData = new FormData(form);

    try {
      const res = await fetch('/api/questions', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        const message = error?.details || error?.message || 'Failed to submit question.';
        throw new Error(message);
      }

      const data = await res.json();
      renderStatus(statusNode, 'success', 'Answer generated!');
      renderEntry(data, true);
      form.reset();
      previewContainer.innerHTML = '';

      setTimeout(() => {
        statusNode.textContent = '';
        statusNode.className = '';
      }, 3000);
    } catch (error) {
      renderStatus(statusNode, 'error', error.message);
    }
  });

  logoutBtn?.addEventListener('click', async () => {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    window.location.href = '/login.html';
  });

  ensureAuth().then((user) => {
    if (user) {
      loadEntries();
    }
  });
}
