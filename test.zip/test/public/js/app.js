const now = new Date();
const yearEl = document.querySelector('[data-year]');
if (yearEl) {
  yearEl.textContent = String(now.getFullYear());
}
